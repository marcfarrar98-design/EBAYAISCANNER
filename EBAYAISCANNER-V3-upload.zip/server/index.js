import express from "express";
import multer from "multer";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 }
});

app.use(express.static(path.join(__dirname, "..", "public")));
app.get("/health", (_req, res) => res.json({ ok: true, version: "3.0.0" }));

app.post("/api/analyse", upload.single("image"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });
    }
    if (!req.file) return res.status(400).json({ error: "Please upload a product photo." });

    const mime = req.file.mimetype || "image/jpeg";
    const dataUrl = `data:${mime};base64,${req.file.buffer.toString("base64")}`;

    const prompt = `You are an expert eBay UK product-identification assistant.
Analyse the supplied product photo. Identify the exact product if possible.

Use web search when useful to verify the product, especially manufacturer, model, MPN and EAN/GTIN.
Do NOT invent an MPN or EAN. If you cannot verify it, return null and explain why.
Prefer UK product information and GBP pricing when available.

Return ONLY valid JSON with these keys:
{
  "productName": string,
  "brand": string|null,
  "model": string|null,
  "mpn": string|null,
  "ean": string|null,
  "gtin": string|null,
  "confidence": "high"|"medium"|"low",
  "identificationNotes": string,
  "seoTitle": string,
  "description": string,
  "category": string,
  "thumbnailSearchQuery": string,
  "searchLinks": [{"title": string, "url": string}],
  "warnings": string[]
}

For seoTitle, create an eBay UK title of max 80 characters, packed with accurate high-value search terms but without keyword stuffing.
For description, write a clean eBay-ready description with product identity, key features and a short condition/contents placeholder. Do not claim specifications that are not visible or verified.
For thumbnailSearchQuery, give a concise search phrase suitable for finding a clean product image.
searchLinks should contain only URLs you are confident are real and directly useful; otherwise return an empty array.`;

    const body = {
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      tools: [{ type: "web_search" }],
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: prompt },
          { type: "input_image", image_url: dataUrl, detail: "high" }
        ]
      }]
    };

    const r = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });

    const raw = await r.text();
    if (!r.ok) {
      return res.status(r.status).json({ error: `OpenAI API error: ${raw.slice(0, 1200)}` });
    }

    const response = JSON.parse(raw);
    let text = response.output_text || "";
    text = text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();

    let result;
    try {
      result = JSON.parse(text);
    } catch {
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start >= 0 && end > start) result = JSON.parse(text.slice(start, end + 1));
      else throw new Error("The AI returned an unexpected response format.");
    }

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || "Analysis failed." });
  }
});

const port = Number(process.env.PORT || 10000);
app.listen(port, "0.0.0.0", () => console.log(`eBay AI Scanner V3 listening on ${port}`));
