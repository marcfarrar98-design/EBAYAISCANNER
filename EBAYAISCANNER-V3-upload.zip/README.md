# eBay AI Scanner V3

Node/Express app for photographing a product and using the OpenAI Responses API with image input and web search to identify it and generate eBay UK listing data.

## Environment variables

- `OPENAI_API_KEY` — required, keep secret.
- `OPENAI_MODEL` — optional; defaults to `gpt-6-luna`.

## Render

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Root directory: blank
